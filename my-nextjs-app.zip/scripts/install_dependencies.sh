#!/bin/bash
# Install application dependencies
cd /var/app/current
npm install
