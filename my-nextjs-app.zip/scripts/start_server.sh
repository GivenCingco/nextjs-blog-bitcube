#!/bin/bash
# Start the Next.js server
cd /var/app/current
npm run start
