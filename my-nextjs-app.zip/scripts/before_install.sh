#!/bin/bash
# Add any commands you need to run before the installation
echo "Running BeforeInstall script"
